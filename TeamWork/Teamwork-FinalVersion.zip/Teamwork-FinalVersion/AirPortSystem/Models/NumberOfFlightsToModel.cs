﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirPortSystem.Models
{
    public class NumberOfFlightsToModel
    {
        public string Destination { get; set; }

        public int NumberOfFlights { get; set; }
    }
}