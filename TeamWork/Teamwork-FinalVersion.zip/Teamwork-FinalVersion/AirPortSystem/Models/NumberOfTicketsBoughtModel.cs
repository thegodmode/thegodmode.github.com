﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirPortSystem.Models
{
    public class NumberOfTicketsBoughtModel
    {
        public DateTime BoughtDate { get; set; }

        public int NumberOfTickets { get; set; }
    }
}